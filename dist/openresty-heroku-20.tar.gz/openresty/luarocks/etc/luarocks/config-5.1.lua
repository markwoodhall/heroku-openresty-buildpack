-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/app/openresty/luarocks" };
}
lua_interpreter = "luajit";
variables = {
   LUA_DIR = "/app/openresty/luajit";
   LUA_BINDIR = "/app/openresty/luajit/bin";
}
